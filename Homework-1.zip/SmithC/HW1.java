import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.PrintWriter; // used to write to positive.txt and negative.txt

/*
 * Channing Smith
 * CSCI 221, Spring 2021, Programming HW 1, Section 1
 *
 * This program analyzes movie review data to determine if words have a
 * negative or positive meaning. If a word is used more often in positive
 * reviews, it is assumed that the word is positive, and vice versa.
 * Currently, it reads review data line by line - each line is a single review in the form:
 * <integer rating of movie> <Written review - text supporting the rating> <newline>
 *
 * The program then allows the user to enter specific files to review and determine whether it is
 * more positive or negative. It also is able to find how many times a specific word is used in a file.
 * The program also shows a menu of options for the user to pick what it wants to do. Finally, for the 
 * bonus problem, it creates two new files of sorted positive and negative words. 
 * 
 * This code was written by me alone, but I did discuss how to approach the bonus problem with one of the 
 * tutors from the Center for Student Learning.
 */
public class HW1
{
    public static void main(String[] args) throws FileNotFoundException
    {
        // Create file instance for input
        File reviewFile = new File("movieReviews.txt");

        // This scanner instance will read from the aforementioned file, which
        // must be in your BlueJ project directory for it to find it.

        // This scanner instance reads from the keyboard
        Scanner keyboard = new Scanner(System.in);

        int reviewScore; // contains the score of the review
        String reviewText; // contains the text of the reviews
        String word; // initializes the string of the word from input
        String fileName; // initializes the string of the file's name

    
        int countOfWords = 0; // initializes the number of words at zero.
        double totalScore = 0; // initializes the total of scores at zero.
        double averageScore = 0; // initializes the average of scores at zero.

            
        String numberEntered = ""; // empty string for the number that the user enters.
        while(numberEntered != "5") // states that the loop will run as long as user does not enter 5, if they do, the program will close.
        {
           // Below creates the questions for the menu options.
           System.out.println("What would you like to do?");
           System.out.println("1: Get the score of a word.");
           System.out.println("2: Get the average score of words in a file (one word per line).");
           System.out.println("3: Find the highest/lowest scoring words in a file.");
           System.out.println("4: Sort words from a file into positive.txt and negative.txt.");
           System.out.println("5: Exit the program.");
           System.out.println("Enter a number 1-5:");

             numberEntered = keyboard.nextLine(); // gets input number from the user
            if (numberEntered.contains("1")) { // this if statement is for when the user inputs "1"
                System.out.println("Enter a word.");
                word = keyboard.nextLine();
                Scanner reviewScanner = new Scanner(reviewFile);

                // This loop iterates as long as there is text in the file.
                countOfWords = 0;
                totalScore = 0;

                while(reviewScanner.hasNext())
                {

                    // Read the numeric movie rating
                    reviewScore = reviewScanner.nextInt();
                    // Read the text of the verbal review
                    reviewText = reviewScanner.nextLine();

                    
                    if(reviewText.contains(word))
                    {
                        countOfWords += 1; // adds one to the number of words if condition is met.
                        totalScore += reviewScore; // updates the total score

                    }
                }
                averageScore = totalScore / countOfWords; // assigns averageScore to the totalScore divided by countOfWords (average) 
                System.out.println("The word " + word + " appeared " + countOfWords + " times.");
                System.out.println("The average score for reviews containing the word " + word + " is: " + averageScore);
                System.out.println("-------------------------------------------------");
            }
            else if (numberEntered.contains("2")) { // this if statement is for when the user inputs "2"
                System.out.println("Enter the name of the file with words you want to find the average score for: "); // gets user input for file name
                fileName = keyboard.nextLine(); // // This scanner instance reads from the keyboard.
                File inputFile = new File(fileName);// This creates a new file.
                Scanner inputScanner2 = new Scanner(inputFile); // Creates a new input scanner for problem 2.

                double totalOfAverages = 0; // initializes the total of all averages of reviews
                int numberOfWords = 0; // initializes the number of words as int.

                while (inputScanner2.hasNext()) {
                    Scanner reviewScanner2 = new Scanner(reviewFile); // Creates a new review scanner that reads the file. 
                    String inputWord = inputScanner2.nextLine();
                    countOfWords = 0;
                    totalScore = 0;

                    while(reviewScanner2.hasNext()) {

                        // Read the numeric movie rating
                        reviewScore = reviewScanner2.nextInt();
                        // Read the text of the verbal review
                        reviewText = reviewScanner2.nextLine();

                        if(reviewText.contains(inputWord)) {

                            countOfWords += 1;
                            totalScore += reviewScore;

                        }
                    }   
                    numberOfWords += 1;
                    averageScore = totalScore / countOfWords;

                    totalOfAverages += averageScore;

                } 

                double averageOfAverages = totalOfAverages / numberOfWords; // averageOfAverages is the average of all the averages 
                System.out.println("The average score of words in " + inputFile + " is: " + averageOfAverages);
                if (averageOfAverages > 2.00) { // if averages is greater than 2.01 must be positive.
                    System.out.println("The overall sentiment of " + inputFile + " is positive.");

                }
                else if (averageOfAverages <= 2.00) {// if averages is less than 1.99 must be negative.
                    System.out.println("The overall sentiment of " + inputFile + " is negative.");
                }
                else {
                    System.out.println("The overall sentiment of " + inputFile + " is neutral.");
                }
                System.out.println("-------------------------------------------------");
            }
            else if (numberEntered.contains("3")) { // this if statement is for when the user inputs "3"

                System.out.println("Enter the name of the file with words you want to score: ");

                fileName = keyboard.nextLine();
                File inputFile = new File(fileName);
                Scanner inputScanner3 = new Scanner(inputFile); // creates new input scanner for problem 3.

                String negWord = ""; // creates empty string for most negative word.
                String posWord = ""; // creates empty string for most positive word.
                double posScore = 0; // initializes positive score
                double negScore = 10;// initializes negative score
                double numberOfWords = 0; // initializes numberOfWords at 0 and double

                while (inputScanner3.hasNext()) { // will run as long as hasNext
                    Scanner reviewScanner3 = new Scanner(reviewFile);
                    String inputWord = inputScanner3.nextLine();
                    countOfWords = 0;
                    totalScore = 0;

                    while(reviewScanner3.hasNext()) {

                        // Read the numeric movie rating
                        reviewScore = reviewScanner3.nextInt();
                        // Read the text of the verbal review
                        reviewText = reviewScanner3.nextLine();

                        if(reviewText.contains(inputWord)) {

                            countOfWords += 1;
                            totalScore += reviewScore;

                        }
                    }   
                    numberOfWords += 1;
                    averageScore = totalScore / countOfWords; // calculates the averageScore

                    if (posScore < averageScore) {
                        posWord = inputWord;
                        posScore = averageScore; // sets posScore equal to averageScore if met.
                    }
                    else if (negScore > averageScore) {
                        negWord = inputWord;
                        negScore = averageScore; // sets negScore equal to averageScore if met.
                    }

                } 
                System.out.println("The most positive word, with a score of " + posScore + " is " + posWord);
                System.out.println("The most negative word, with a score of " + negScore + " is " + negWord);
                System.out.println("-------------------------------------------------");
            }
            else if (numberEntered.contains("4")) { // this if statement is for when the user inputs "4" (bonus question)
                System.out.println("Enter the name of the file you want to sort into positive/negative words.");
                fileName = keyboard.nextLine();
                File inputFile = new File(fileName);

                double numberOfWords = 0;

                Scanner inputScanner4 = new Scanner(inputFile); // creates a new inputScanner for problem 4.
                
                // Below is used to create and write to two new files: postive.txt and negative.txt
                PrintWriter writingFilePos = null;
                writingFilePos = new PrintWriter(new File("positive.txt"));
                PrintWriter writingFileNeg = null;
                writingFileNeg = new PrintWriter(new File("negative.txt"));
                while (inputScanner4.hasNext()) {
                    Scanner reviewScanner4 = new Scanner(reviewFile); // creates new reviewScanner for problem 4.
                    String inputWord = inputScanner4.nextLine();
                    countOfWords = 0;
                    totalScore = 0;

                    while(reviewScanner4.hasNext()) { // will run as long as hasNext.

                        // Read the numeric movie rating with review scanner 4.
                        reviewScore = reviewScanner4.nextInt();
                        // Read the text of the verbal review with review scanner 4.
                        reviewText = reviewScanner4.nextLine();

                        if(reviewText.contains(inputWord)) {

                            countOfWords += 1; // adds one to countOfWords everytime the condition is met.
                            totalScore += reviewScore; // means totoalScore equals totalScore plus reviewScore if met.

                        }
                    }   
                    numberOfWords += 1; // adds one to numberOfWords 
                    averageScore = totalScore / countOfWords; // sets the value of averageScore
                    
                    if (averageScore > 2.00) { // writes words to positive.txt
                        writingFilePos.write(inputWord + "\n");
                        writingFilePos.flush();

                    }
                    else if (averageScore <= 2.00) { // writes words to negative.txt
                        writingFileNeg.write(inputWord + "\n");
                        writingFileNeg.flush();
                    
                    }
                
            } 
                writingFilePos.close(); // closes the file.
                writingFileNeg.close(); // closes the file.
                System.out.println("-------------------------------------------------");
        }
            else if (numberEntered.contains("5")) { // this if statement is for when the user inputs "5" which closes program
                System.out.println("-------------------------------------------------");
                System.exit(0); // exits the program.
        }
            else { // this if statement is for if the user inputs an invalid number that isn't between 1 and 5.
                System.out.println("This is not a valid number to be entered.");
                System.out.println("-------------------------------------------------");
        }
    }
}
}
