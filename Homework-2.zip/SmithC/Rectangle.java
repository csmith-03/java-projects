// This code was my own work and it was written without consulting with code written by other students or copied from online resources.
// Channing Smith
// HW2, Section 1, Spring 2021
// This file represents a rectangle shape.
// This code was written by me alone, but I did attend CSL.

// This class represents a rectangle shape
public class Rectangle {

        private double L; // the length of the rectangle
        private double H; // the height of the rectangle
        private double x; // the x coordinate of the  bottom left corner of the rectangle
        private double y; // the y coordinate of the bottom left corner of the rectangle

        // Constructor that creates a rectangle with 
        // side lengths 1 whose bottom left corner is at (0.0,0.0)
        public Rectangle() {
            L = 1.0;
            H = 1.0;
            x = 0.0;
            y = 0.0;
        }
            

        // Constructor that takes all four inputs,and assigns them to new names
        // named Ell, Eich, Ex, and Why for L, H, x, and y, respectively.
        public Rectangle(double Ell, double Eich, double Ex, double Why) {
            this.L = Ell;
            this.H = Eich;
            this.x = Ex;
            this.y = Why;
        }
    

        // getLength() method which returns the length
        public double getLength() {
            return L;
        }

        // getHeight() method which returns the height
        public double getHeight() {
            return H;
        }

        // setLength() method which takes as input a double
        // called Ell and uses it to set the length of the rectangle.
        public void setLength(double Ell) {
            this.L = Ell;
        }

        // setHeight() method which takes as input a double
        // called Eich and uses it to set the height of the rectangle.
        public void setHeight(double Eich) {
            this.H = Eich;
        }

        // perimeter() method which computes and returns
        // the perimeter of the rectangle.
        public static double perimeter(double Eich, double Ell) {
            double perimeterOfRect = (Eich + Ell) * 2.0;
            return perimeterOfRect;
        }
        

        //area() method which computes and returns the
        // area of the rectangle.
        public static double area(double Eich, double Ell) {
            double areaOfRect = Eich * Ell;
            return areaOfRect;
        }
        
        // public static void main(String[] args) {
                // // Test for .getLength() and .getHeight()
                // double rec = new Rectangle(2, 3, 4, 8).getLength(); //2.0
                // double rec2 = new Rectangle(2, 3, 4, 8).getHeight(); //3.0
                // System.out.println(rec);
                // System.out.println(rec2);
                // //Test for perimeter and area
                // Rectangle x = new Rectangle(2, 3, 0, 0);
                // Rectangle y = new Rectangle(12, 8, 0, 0);
		
		// // x.setHeight(16);
		// // x.setLength(4);
		
		// System.out.println(x.getHeight()); //16.0
		// System.out.println(x.getLength()); //4.0
        
        	// double height_x = x.getHeight(); //2.0
        	// double length_x = x.getLength(); //3.0
        		//
        	// double height_y = y.getHeight(); //15.0
        	// double length_y = y.getLength(); //17.0
        	// System.out.println(perimeter(height_x, length_x)); // 10.0
        	// System.out.println(perimeter(height_y, length_y)); // 40.0
        	// System.out.println(area(height_x, length_x)); // 6.0
        	// System.out.println(area(height_y, length_y)); // 96.0
		
	 // }
}
