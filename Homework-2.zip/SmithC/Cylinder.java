// This code was my own work and it was written without consulting with code written by other students or copied from online resources.
// Channing Smith
// HW2, Section 1, Spring 2021
// This file represents a cylinder.
// This code was written by me alone, but I did attend CSL.

// This class represents a cylinder 
public class Cylinder extends Circle {
    protected double z = 0.0;
    protected double height;
    
    // Default constructor Cylinder()and no arguments are passed
    public Cylinder() {
        // Initializing the instance variable values
        x = 0.0;
        y = 0.0;
        z = 0.0;
        height = 1.0;
        radius = 1.0;
    }
    
    // Constructor with x, y, radius, and height also renames them
    public Cylinder(double Ex, double Why, double radRad, double Hi) {
        this.x = Ex;
        this.y = Why;
        this.radius = radRad;
        this.height = Hi;
        z = 0.0;
    }
    
    // getHeight() returns the height of the cylinder
    public double getHeight() {
        return height;
    }
    
    // setHeight() sets the height of the cylinder as the value
    public void setHeight(double heightSet) {
        this.height = heightSet;
    }
    
    // getArea() overrides method in Circle class and also finds area of cylinder
    public double getArea() {
        return (2 * Math.PI * radius * height) + (2 * super.getArea());
    }
    
    // getVolume() computes the volume of the cylinder using getArea() from Circle
    public double getVolume() {
        return super.getArea() * height;
    }
    
    // Test cases for methods are below
    // public static void main(String[] args) {
        //Cylinder cyl1 = new Cylinder(2, 4, 6, 8);
        // // Test case for getHeight()
        // System.out.println(cyl1.getHeight()); // 8.0
        // // Test case for setHeight()
        // cyl1.setHeight(5);
        // System.out.println(cyl1.getHeight()); // 5.0
        // // Test case for getArea()
        // System.out.println(cyl1.getArea()); // 414.69023027385265
        // // Test case for getVolume 
        // System.out.println(cyl1.getVolume()); // 565.4866776461628
    // }
}