// This code was my own work and it was written without consulting with code written by other students or copied from online resources.
// Channing Smith
// HW2, Section 1, Spring 2021
// This file represents a circle shape.
// This code was written by me alone, but I did attend CSL.

public class ShapeTester {

  // The method isLarger() takes two shapes
  // (a Circle first, then a Rectangle) and returns true if the area of
  // the circle is bigger than (or equal to) the area of the rectangle,
  // false otherwise.
  public static boolean isLarger(Circle circ, Rectangle rect) {
      double heightLarger = rect.getHeight();
      double lengthLarger = rect.getLength();
      if (circ.getArea() >= rect.area(heightLarger, lengthLarger)) {
          return true;
      }
      else {
          return false;
      }
  }
  
  // The method longerPerim() takes a Circle object as input followed by a Rectangle object and returns
  // the length of the perimeter of the longer of the two objects.
  public static double longerPerim(Circle circ, Rectangle rect) {
      double heightPerim = rect.getHeight();
      double lengthPerim = rect.getLength();
      if (circ.getCircumference() > rect.perimeter(heightPerim, lengthPerim)) {
          return circ.getCircumference();
      }
      else {
            return rect.perimeter(heightPerim, lengthPerim);
      }
  }

  // The method longerPerim() which has the same name and functionality as the last but it takes 
  // a Rectangle object as input followed by a Circle object. 
  // The method also returns the length of the perimeter of the longer of the two objects.
  public static double longerPerim(Rectangle rect, Circle circ) {
      double heightPerim2 = rect.getHeight();
      double lengthPerim2 = rect.getLength();
      if (circ.getCircumference() > rect.perimeter(heightPerim2, lengthPerim2)) {
          return circ.getCircumference();
      }
      else {
          return rect.perimeter(heightPerim2, lengthPerim2);
      }
  }

  // The method largerArea() which takes a Circle object as input followed by a Rectangle object and returns
  // the area of the larger of the two objects.
  public static double largerArea(Circle cForArea, Rectangle rForArea) {
      double heightArea = rForArea.getHeight();
      double lengthArea = rForArea.getLength();
      if (cForArea.getArea() > rForArea.area(heightArea, lengthArea)) {
          return cForArea.getArea();
      }
      else {
          return rForArea.area(heightArea, lengthArea);
      }
  }
  

  // The method largerArea() which has the same name and functionality as the last but it 
  // takes  a Rectangle object followed by a Circle object as input.
  public static double largerArea(Rectangle rForArea2, Circle cForArea2) {
      double heightArea2 = rForArea2.getHeight();
      double lengthArea2 = rForArea2.getLength();
      if (cForArea2.getArea() > rForArea2.area(heightArea2, lengthArea2)) {
          return cForArea2.getArea();
      }
      else {
            return rForArea2.area(heightArea2, lengthArea2);
      }
  }
  
  // The method containsCenter() which takes two circles as input and returns true if the first circle 
  // contains the center of the second circle, false otherwise.
  public static boolean containsCenter(Circle objOne, Circle objTwo) {
      double[] centerCircTwo = objTwo.getCenter();
      double[] centerCircOne = objOne.getCenter();
      if (Math.pow(Math.pow(centerCircTwo[0] - centerCircOne[0], 2) + Math.pow(centerCircTwo[1] - centerCircOne[1], 2), 0.5) <= objOne.getRadius()) {
          return true;
        }
      else {
          return false;
      }
  }
  
  // Test cases are below 
  // public static void main(String[] args) {
     // Circle testCirc = new Circle(4, 4, 4);
     // Rectangle testRect = new Rectangle(5, 10, 0, 0);
     // Circle testCirc2 = new Circle(12, 6, 6.5);
     // Rectangle testRect2 = new Rectangle(2, 4, 0, 0);



     // //Test for isLarger()
     // System.out.println(isLarger(testCirc, testRect)); // true 
     // System.out.println(isLarger(testCirc2, testRect2)); // true 

     // //Test for longerPerim
     // System.out.println(longerPerim(testCirc, testRect));// 30.0
     // System.out.println(longerPerim(testRect2, testCirc));// 25.132741228718345

     // //Test for largerArea
     // System.out.println(largerArea(testCirc2, testRect)); // 452.3893421169302
     // System.out.println(largerArea(testRect2, testCirc2)); // 452.3893421169302

     // //Test for containsCenter
     // System.out.println(containsCenter(testCirc, testCirc2)); //true
     // System.out.println(containsCenter(testCirc2, testCirc)); //true

  // }
}
