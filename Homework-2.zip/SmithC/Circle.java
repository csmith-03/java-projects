// This code was my own work and it was written without consulting with code written by other students or copied from online resources.
// Channing Smith
// HW2, Section 1, Spring 2021
// This file represents a circle shape.
// This code was written by me alone, but I did attend CSL.

 
// This class represents a circle shape

public class Circle {

    // Instance variables (data members) of class Circle
    protected double radius; // the radius of the circle
    protected double x; // the x coordinate of the circle's center
    protected double y; // the y coordinate fo the circle's center

    // The default constructor with no argument
    public Circle(){
      // Initializing the values of the instance variables
      radius = 1.0;
      x = 0.0;
      y = 0.0;
    }

    // Second constructor with given radius, but origin default
    public Circle(double r) {
      radius = r;
      x = 0.0;
      y = 0.0;
    }

    // Overloaded constructor that assigns new names to existing/ old Circle parameters.
    public Circle(double r, double ex, double why) {
        // ... Add your code here ... //
        this.radius = r; // why is this not working? should it be .length()
        this.x = ex;
        this.y = why;
        
    }

    // A public getter method for retrieving the radius
    public double getRadius() {
     return radius;
    }

    // A public getter method for retrieving the center coordinates
    public double[] getCenter() {
     double[] c = {this.x, this.y};
     return c;
    }

    // A public getter method for computing and returning
    // the area of the circle
    public double getArea() {
      return radius * radius * Math.PI;
    }

    // TODO: [2 points] A public method you need to write to
    // compute and return the circumference of the circle
    public double getCircumference() {
        // ... Add your code here ... //
        return radius * 2 * Math.PI;
    }

    // Compares the area of two circles and determines if one is bigger than the other. Uses a boolean to return true or false.
    public boolean isBiggerThan(Circle circle2) { // not sure ab this parameter
      if (this.getArea() > circle2.getArea()) {
          return true;
      }
      else {
          return false;
      }
    }

    // Uses x and y coordinates of a point to return a boolean true or false which shows whether the point is in circle object.
    public boolean containsPoint(double x_point, double y_point) {
        // ... Add your code here ... //
        double[] center_circle = this.getCenter();
        if (Math.pow(Math.pow(x_point - center_circle[0], 2) + Math.pow(y_point - center_circle[1], 2), 0.5) <= this.getRadius()) {
            return true;
        }
        else {
            return false;
        }
    }

    // Uses double value to set a new radius for circle object
    public void setRadius(double rad) {
        this.radius = rad;
    }

    // Uses two double values as the parameter to set new x and y coordinates that shows center of circle object
    public void setCenter(double ex, double why) {
        this.x = ex;
        this.y = why;
    }

    // Returns a string representation of circle object
    @Override
    public String toString() {
        double [] centerFinal = this.getCenter();
        return "This circle is centered at point (" + centerFinal[0] + ", " + centerFinal[1] + ") with radius " + this.getRadius();
    }
         // Test cases are below 
         
        // public static void main(String[] args) {
         // Test case for getCircumference()
         // double cir = new Circle(0.0, 0.0, 0.0).getCircumference();
         // double cir2 = new Circle(16.0, 4.0, 2.0).getCircumference();
         // double cir3 = new Circle(24.0, 12.0, 3.0).getCircumference();
         
         // System.out.println(cir);
         // System.out.println(cir2);
         // System.out.println(cir3);
         
         // Test cases for isBiggerThan()
         // Circle x = new Circle(1, 1, 1);
         // Circle y = new Circle(0.0, 0.0, 0.0);
         
         // System.out.println(y.isBiggerThan(x)); // false
         // System.out.println(x.isBiggerThan(y)); // true
         
         // Test cases for containsPoint()
         // System.out.println(x.containsPoint(1.0, 1.0)); // true
         // System.out.println(y.containsPoint(1.0, 1.0)); // false
         
         // Test case for toSting()
         // System.out.println(x.toString()); // This circle is centered at point (1.0, 1.0) with radius 1.0
         
         
        //}
}
