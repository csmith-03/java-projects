// Channing Smith
// HW3, CSCI 221-Section 01, Spring 2021
// This program implements a dictionary to be used for 
// storing and managing words in the Star Trek language Klingon. This dictionary program 
// will support functions like building a dictionary, adding words, deleting words, 
// searching for words, and so on.
// This code was my own work, it was written without consulting code written by other
// students or copied from online resource.
// - Channing Smith */

import java.util.ArrayList;


// This class represents a dictionary of Klingon words,
// where each word is represented by class "KlingWord"
public class KlingDictionary {

  // one member variable that represents the dictionary as an ArrayList;
  // all methods below will add/read/remove/etc. from this variable
  public ArrayList<KlingWord> dict;

  // constructor
  public KlingDictionary () {
      dict = new ArrayList<KlingWord>();
  }

  // Helper method to build the dictionary "dict" from two String arrays
  // Returns the number of words that have been added successfully
  /*** Warning: Do NOT modify this method ***/
  public int buildDictionary() {
    // A list of Klingon words to be added to this dictionary
    String[] knWordsArray= {"adanji", "baH", "baktag", "batleth", "Bekk", "fote", "forshak", "ghoptu", "lok",   "eff", "grr",   "keshmalek",    "drumpf", "daH", "Kyamo"};
    // The corresponding English translations are stored in the same order below
    String[] enWordsArray = {"perfume", "blah", "insult", "sword", "soldier", "vote", "car", "insult", "look", "insult", "insult", "gameover", "prince", "duh", "Beautiful"};

    // Variables to be used inside the for-loop
    String knWord = "";
    String enWord = "";
    int numWords = 0;
    for(int i = 0; i < knWordsArray.length; i++) {
        knWord = knWordsArray[i];  //read the KN word
        enWord = enWordsArray[i];  //read the corresponding EN translation
        KlingWord word = new KlingWord(knWord, enWord); //create a KlingWord object

        addWord(word); //this will only work properly after you implement addWord() below!!
        numWords++; //update word counter
    }

    return numWords;
  }
  
  // -------------- Assignment#1 Dictionary Methods Below -------------- //
  /* Add a new Klingon word to the dictionary member variable "dict".
  * The dictionary must NOT include duplicate Klingon words; however,
  * two (or more) Klingon words may have the same English translation (i.e. same "en").
  *
  * Return 0 if addition was successful, -1 otherwise. */
  public int addWord(KlingWord newWord) {
    boolean matches = true;
    int success = 0;
    for(int i = 0; i < dict.size(); i++) {
        KlingWord old = dict.get(i);
        matches = old.getKN().equalsIgnoreCase(newWord.getKN());
        if (matches == false) {
            success = 0;
        }
        else {
            success = -1;
            break;
        }
  
    }
    if (success == 0) {
        dict.add(newWord);
        
    }
    return success;
  }
  /* Check if the Klingon word in "oldWord" exists in the dictionary "dict"
  * (regardless of the English meaning), then:
  * If you do find oldWord => remove it from the dictionary then insert "newWord" in
  * the exact same location where you removed oldWorld.
  * If you don't find "oldWord" => add "newWord" normally at the end of the dictionary.
  *
  * Return 0 if a replacement did happen (i.e. you found oldWord), -1 otherwise. */
  public int replaceOrAddWord(KlingWord oldWord, KlingWord newWord) {
    boolean matches = true;
    int success = -1;
    for(int i = 0; i < dict.size(); i++) {
        KlingWord wordCompared = dict.get(i);
        matches = wordCompared.getKN().equalsIgnoreCase(oldWord.getKN());
        if (matches == false) {
            success = -1;
        }
        else {
            success = 0;
            dict.set(i, newWord);
            break;
        }
    }
    if (success == -1) {
        addWord(newWord);
    }
    
    return success;
  }


  /* Delete all Klingon words that have the English meaning given
  * in "badEN" from the dictionary "dict".
  *
  * Return the number of words that were deleted successfully. */
  public int deleteFromDict(String badEN){
    boolean matches = true;
    int count = 0;
    for(int i = 0; i < dict.size(); i++) {
        String checkWord = dict.get(i).getEN();
        matches = checkWord.equalsIgnoreCase(badEN);
        if (matches == true) {
            dict.remove(i);
            count++;
            i--;
        }
    }
    return count;
  }


  /* The new Klingon leader decided that long words are just stupid.
  /* Implement this law which removes any Klington word from the dictionary
  /* that is longer than 3 characters (regardless of the English translation's length) */
  public void shortDict(){
    int limit = 3;
    for(int i = 0; i < dict.size(); i++) {
        String checkWord = dict.get(i).getKN();
        int letters = checkWord.length();
        if (letters > limit) {
            dict.remove(i);
            i--;
        }
    }
  }
  /* One dictionary is not enough? Let's create another one!
  * Find all the Klingon words in "dict" whose first and last
  * characters are identical (e.g. "kwerk"). Now create a new dictionary
  * that contains these special words. Don't remove the words from the
  * original dictionary.
  *
  * Return the newly created dictionary. */
  public KlingDictionary createSubDict(){
    KlingDictionary newDict = new KlingDictionary();
    for(int i = 0; i < dict.size(); i++) {
        String checkWord = dict.get(i).getKN(); 
        char firstL = checkWord.charAt(0);
        char lastL = checkWord.charAt(checkWord.length() - 1);
        if (firstL == lastL) {
            newDict.addWord(dict.get(i));
    }
    
  }
    return newDict;
  }

  //*Prints all the KlingWord objects inside the ArrayList dict.
  /* Remember: the method toString() in class KlingWord will be invoked automatically
  /* when an object of class KlingWord is passed to System.out.println(). */
  public void printDictionary(){
    for( KlingWord kw : dict ){
      System.out.println(kw);
    }
  }


  // Main method includes constructing your dictionary and testing its methods
  public static void main(String[] args) {
    int result;
    KlingDictionary klingdict = new KlingDictionary();

    // Build the dictionary
    result = klingdict.buildDictionary();
    System.out.println("buildDictionary() result => " + result);
    // Print dictionary
    klingdict.printDictionary();

    // Add word
    result = klingdict.addWord(new KlingWord("klingothing","nothing"));
    // Remember, '\n' below stands for: print a "new line"
    System.out.println("\naddKlingWordictoDict() result => " + result);
    klingdict.printDictionary();

    // Replace or add word
    KlingWord testword = new KlingWord("forshak","vehicle");
    KlingWord newWord = new KlingWord("gamma","beta");
    result = klingdict.replaceOrAddWord(testword, newWord);
    System.out.println("\nreplaceOrAddWord(" + testword.getKN() +
                "," + newWord.getKN() + ") result => " + result);
    klingdict.printDictionary();

    // Get special words in a new dictionary
    KlingDictionary specialDict = klingdict.createSubDict();
    System.out.println("\nCalled createSubDict()...");
    specialDict.printDictionary(); // print new dictionary with special words

    // Apply new law that requires removing long words
    klingdict.shortDict();
    System.out.println("\nApplied shortenDict()...");
    klingdict.printDictionary();

    // Delete all words that have this English meaning
    String badEN = "insult";
    result = klingdict.deleteFromDict(badEN);
    System.out.println("\ndeleteFromDict() result => " + result);
    klingdict.printDictionary();

  }

}
