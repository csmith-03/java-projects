// Channing Smith
// HW4, CSCI 221 Section 1, Spring 2021
// The purpose of the code in this file is to find a path 
// to exit a maze using Java's Stack class.
// This code was my own work, it was written without consulting with
// other students or copied from online resources.
// Channing Smith


import java.util.Stack;
import java.util.Scanner;
import java.util.Arrays;
import java.util.List;
import java.io.IOException;
import java.io.FileInputStream;

public class MazeSolver {

  static char[][] maze;
  static int startX, startY;  // indices for starting the maze search
  static int endX, endY; // indices for ending the maze search

  // Constructor that creates the maze
  public MazeSolver(String fileName) throws IOException {
    startX = 0;
    startY = 0;
    readMaze(fileName); // initialize maze
  }

  // Helper method for reading the maze content from a file
  public static void readMaze(String filename) throws IOException {
    Scanner scanner;
    try{
      scanner = new Scanner(new FileInputStream(filename));
    }
    catch(IOException ex){
      System.err.println("[ERROR] Invalid filename: " + filename);
      return;
    }

    int N = scanner.nextInt();
    scanner.nextLine();
    maze = new char[N][N];
    endX = N-1; endY = N-1;
    int i = 0;
    while(i < N && scanner.hasNext()) {
      String line =  scanner.nextLine();
      String [] tokens = line.split("\\s+");
      int j = 0;
      for (; j< tokens.length; j++){
        maze[i][j] = tokens[j].charAt(0);
      }
      if(j != N){
        System.err.println("[ERROR] Invalid line: " + i + " has wrong # columns: " + j);
        return;
      }
      i++;
    }
    if(i != N){
      System.err.println("[ERROR] Invalid file: has wrong number of rows: " + i);
      return;
    }
  }

  // Helper method for printing the maze in a matrix format
  public void printMaze() {
     for (int i=0; i < maze.length; i++) {
         for (int j=0; j < maze.length; j++) {
           System.out.print(maze[i][j]);
           System.out.print(' ');
          }
          System.out.println();
     }
  }

  // Helper method to keep track of visited positions 
  public boolean visitedPos(MazePosition closePos, Stack <MazePosition> visitedPos) {
      int givenX = closePos.getX();
      int givenY = closePos.getY();
      for (int i = 0; i < visitedPos.size(); i++) {
          // finds x and y
          int xPos = visitedPos.get(i).getX();
          int yPos = visitedPos.get(i).getY();
          // see if x and y are equal to what is given
          if (xPos == givenX & yPos == givenY) {
              return true;
            }
        }
        return false;
    }
    // Helper method that keeps track of valid positions.
  public boolean validPos(int lastPos, MazePosition closePos, Stack <MazePosition> visitedPos) {
      // defines varivales for the given x and y   
      int givenX = closePos.getX();
        int givenY = closePos.getY();
        // boolean for determining if pos is inside of maze
        boolean isElement = givenX <= lastPos & givenX >= 0 & givenY <= lastPos & givenY >= 0;
        // if statement is for if if the valid pos is an element and visited position.
        if (isElement & !visitedPos(closePos, visitedPos)) {
            if (maze[givenX][givenY] == '0') {
                return true;
            }
        }
        return false;
  }
 
  public void solveMaze() {
    Stack <MazePosition> visitedPos= new Stack <MazePosition>();
    Stack <MazePosition> posToCheck = new Stack <MazePosition>();
    
   
    // create entrance and push it 
    MazePosition entrancePos = new MazePosition(0, 0);
    
    
    // create exit
    int exitPos = maze.length - 1;
    // push entrrance position
    posToCheck.push(entrancePos);
    
    // start while loop below that runs as long as posToCheck isnt empty
    while (!posToCheck.empty()) {
        // creates object currentPos by using pop and creates an x and y for that position
        MazePosition currentPos = posToCheck.pop();
        // creates x and y position variables
        int xPos = currentPos.getX();
        int yPos = currentPos.getY();
        
        // see if x and y are equal to exit 
        if (xPos == exitPos & yPos == exitPos) {
            // make success 
            maze[xPos][yPos] = 'X';
            System.out.println("Maze is solvable.");
            // break out of the loop
            break;
        }
        else {
            // push positoion to vistited 
            visitedPos.push(currentPos);
            // if position is at zero, mark it with an x
            if (maze[xPos][yPos] == '0') {
                maze[xPos][yPos] = 'X';
            }
            // creates position objects 
            MazePosition upPos = new MazePosition(xPos - 1, yPos);
            MazePosition downPos = new MazePosition(xPos + 1, yPos);
            MazePosition leftPos = new MazePosition(xPos, yPos - 1);
            MazePosition rightPos = new MazePosition(xPos, yPos + 1);
            
            // create list below
            List <MazePosition> closePos = Arrays.asList(leftPos, downPos, upPos, rightPos);
            
            for (int i = 0; i < 4; i++) {
                // push to left if valid
                if (validPos(exitPos, closePos.get(i), visitedPos)) {
                    posToCheck.push(closePos.get(i));
                }
            }
        }
    }
    if( posToCheck.empty()) {
        // not solvable if the posToCheck is empty when exit begins
        System.out.println("Maze is NOT solvable.");
    }
  }

  public static void main(String[] args) throws IOException {
    // If no argument is provided, show error message
    if(args.length < 1) {
      System.err.println("[ERROR] Usage: java PathFinder maze_file");
      System.exit(-1);
    }
    // File name is provided properly as the first argument
    String fileName =  args[0];

    MazeSolver ms = new MazeSolver(fileName);
    System.out.println("[Before Traversal] Maze:");
    ms.printMaze();
    System.out.println();

    // Test solver
    ms.solveMaze();
    System.out.println();
    System.out.println("[After Traversal] Maze:");
    ms.printMaze();
  }

}
